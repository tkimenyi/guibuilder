package componenttree;

import gui.UserGUI;

import java.awt.Component;
import java.awt.Dimension;

import javax.swing.JComponent;
import javax.swing.JPanel;

public class ComponentManager {
	
	private ContainerItem root;
	private ComponentItem focusedItem;
	private int size;
	
	public ComponentManager(){
		this.root = null;
		this.focusedItem = null;
		this.size = 0;
	}
	
	public void setRoot(ContainerItem component){
		this.root = component;
		this.focusedItem = root;
	}
	
	public int getSize(){
		return this.size;
	}
	
	public ContainerItem getRoot(){
		return this.root;
	}
	
	public ComponentItem getFocusedItem(){
		return this.focusedItem;
	}
	
	public void setFocusedItem(ComponentItem item){
		this.focusedItem = item;
	}
	
	/*add child using border layout*/
	public void addBorderChild(ContainerItem parent, ComponentItem child, String borderLocation, String type, Dimension size){
		ComponentItem panel = addChild(parent, child, type, size);
		panel.setBorderLocation(borderLocation);
	}
	public ComponentItem addChild(ContainerItem parent, ComponentItem child, String type, Dimension size){
		parent.addChildComponent(child);
		child.setParent(parent);
		parent.setPreferredSize(size);
		this.size++;
		return child;
	}

	public void addGridChild(ContainerItem parent, ComponentItem child, int xLoc, int yLoc, String type, Dimension size){
		ComponentItem panel = addChild(parent, child, type,size);
		panel.setGridLocation(xLoc, yLoc);
		panel.setPreferredSize(size);		
	}
	
	public void addGridChild(ContainerItem parent, ComponentItem child, int xLoc, int yLoc, int rowSpan, int colSpan, Dimension size){
		parent.addChildComponent(child);
		child.setParent(parent);
		child.setGridLocation(xLoc, yLoc);
		child.setGridSpan(rowSpan, colSpan);
		child.setPreferredSize(size);
	}
}
