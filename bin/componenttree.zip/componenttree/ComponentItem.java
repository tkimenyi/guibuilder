package componenttree;
import java.awt.Dimension;
import java.awt.Point;

import javax.swing.JComponent;

/*
 * Not sure about what methods will go in this class
 */
public class ComponentItem {
	private String type;
	private JComponent component;
	private Point gridLocation;
	private Point gridSpan;
	private String borderLocation = "";
	private ContainerItem parent;


	public ComponentItem(JComponent component,String type){
		this.component = component;
		this.type = type;
		gridSpan = new Point(1, 1);
		gridLocation = new Point(-1, -1);
		this.parent = null;

	}

	public String getType(){return this.type;}
	public String getBorderLocation(){return this.borderLocation;}
	
	public Point getGridLocation(){return this.gridLocation;}

	public Point getGridSpan(){return this.gridSpan;}

	public ContainerItem getParent(){return this.parent;}

	public void setGridLocation(int x, int y){this.gridLocation.setLocation(x, y);}

	public void setGridSpan(int rows, int cols){this.gridSpan.setLocation(rows, cols);}

	public void setParent(ContainerItem container){
		this.parent = container;
	}
	
	public JComponent getComponent(){return this.component;}

	public void setBorderLocation(String location){this.borderLocation = location;}

	public void setPreferredSize(Dimension size){
		this.component.setPreferredSize(size);
	}

	public Dimension getPreferredSize(){return this.component.getPreferredSize();}

}
