package componenttree;

import javax.swing.*;

import static org.junit.Assert.*;

import java.awt.*;

import org.junit.Test;

public class ComponentTreeTest {

	@Test
	public void test() {
		ComponentManager tree = new ComponentManager();
		assertEquals(tree.getSize(), 0);
		ContainerItem comp = new ContainerItem(new JPanel(), "JPanel");
		ControlItem button = new ControlItem(new JButton(),"JButton");
		ContainerItem mom = new ContainerItem(new JPanel(), "JFrame");
		tree.setRoot(mom);
		tree.addChild(mom, comp, "JPanel", new Dimension(600,600));
		tree.addChild(comp, button, "JButton", new Dimension (100,30));
		assertEquals(tree.getSize(), 2);
		ContainerItem root = tree.getRoot();
		assertEquals(root, mom);
		assertEquals(button.getParent(), comp);
	}

}
