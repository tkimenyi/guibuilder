package componenttree;
import java.awt.Dimension;
import java.awt.Point;

import javax.swing.JComponent;

/*
 * Not sure about what methods will go in this class
 */
public class ComponentItem {
	private String type;
	private JComponent component;
	private Point gridLocation;
	private Point gridSpan;
	private String borderLocation = "";
	private ContainerItem parent;


	public ComponentItem(JComponent component,String type){
		this.component = component;
		this.type = type;
		gridSpan = new Point(1, 1);
		gridLocation = new Point(-1, -1);
		this.parent = null;

	}
	
	/*add child using border layout*/
	public void addBorderChild(ContainerItem parent, ComponentItem child, String borderLocation, String type, Dimension size){
		ComponentItem panel = addChild(parent, child, type, size);
		panel.setBorderLocation(borderLocation);
		parent.addChildComponent(child);
	}
	public ComponentItem addChild(ContainerItem parent, ComponentItem child, String type, Dimension size){
		parent.addChildComponent(child);
		child.setParent(parent);
		parent.setPreferredSize(size);
		parent.addChildComponent(child);
		return child;
	}

	public void addGridChild(ContainerItem parent, ComponentItem child, int xLoc, int yLoc, String type, Dimension size){
		ComponentItem panel = addChild(parent, child, type,size);
		panel.setGridLocation(xLoc, yLoc);
		panel.setPreferredSize(size);	
		parent.addChildComponent(child);
	}

	public void addGridChild(ContainerItem parent, ComponentItem child, int xLoc, int yLoc, int rowSpan, int colSpan, Dimension size){
		parent.addChildComponent(child);
		child.setParent(parent);
		child.setGridLocation(xLoc, yLoc);
		child.setGridSpan(rowSpan, colSpan);
		child.setPreferredSize(size);
		parent.addChildComponent(child);
	}

	public String toString(ComponentItem component){
		if(component instanceof ContainerItem){
			String temp = component.getType() + "\n";
			for(ComponentItem item : ((ContainerItem) component).getChildren()){
				temp += toString(item) + "\t";
			}
			return temp;
		}else{
			return component.getType();
		}
	}

	public String getType(){return this.type;}
	public String getBorderLocation(){return this.borderLocation;}
	
	public Point getGridLocation(){return this.gridLocation;}

	public Point getGridSpan(){return this.gridSpan;}

	public ContainerItem getParent(){return this.parent;}

	public void setGridLocation(int x, int y){this.gridLocation.setLocation(x, y);}

	public void setGridSpan(int rows, int cols){this.gridSpan.setLocation(rows, cols);}

	public void setParent(ContainerItem container){
		this.parent = container;
	}
	
	public JComponent getComponent(){return this.component;}

	public void setBorderLocation(String location){this.borderLocation = location;}

	public void setPreferredSize(Dimension size){
		this.component.setPreferredSize(size);
	}

	public Dimension getPreferredSize(){return this.component.getPreferredSize();}

}
