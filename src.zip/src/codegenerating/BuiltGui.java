package codegenerating;
import javax.swing.*;
public class BuiltGui extends JPanel {
public static void main(String[] args){
JFrame frame = new JFrame("user gui");
JPanel jpanel1=new JPanel();
JPanel jpanel1=new JPanel();
JPanel jpanel2=new JPanel();
JPanel jpanel3=new JPanel();
JPanel jpanel4=new JPanel();
JPanel jpanel5=new JPanel();
JPanel jpanel6=new JPanel();
JPanel jpanel7=new JPanel();
JPanel jpanel8=new JPanel();
JPanel jpanel9=new JPanel();
JPanel jpanel10=new JPanel();
JPanel jpanel11=new JPanel();
JPanel jpanel12=new JPanel();
JPanel jpanel13=new JPanel();
JPanel jpanel14=new JPanel();
JPanel jpanel15=new JPanel();
JPanel jpanel16=new JPanel();
JPanel jpanel17=new JPanel();
JPanel jpanel18=new JPanel();
JPanel jpanel19=new JPanel();
JPanel jpanel20=new JPanel();

jpanel1.add(jpanel2);
jpanel1.add(jpanel3);
jpanel1.add(jpanel4);
jpanel1.add(jpanel5);
jpanel1.add(jpanel6);
jpanel1.add(jpanel7);
jpanel1.add(jpanel8);
jpanel1.add(jpanel9);
jpanel1.add(jpanel10);
jpanel1.add(jpanel11);
jpanel1.add(jpanel12);
jpanel1.add(jpanel13);
jpanel1.add(jpanel14);
jpanel1.add(jpanel15);
jpanel1.add(jpanel16);
jpanel1.add(jpanel17);
jpanel1.add(jpanel18);
jpanel1.add(jpanel19);
jpanel1.add(jpanel20);
jpanel1.add(jpanel21);

frame.add(jpanel1);frame.add(jpanel2);frame.add(jpanel3);frame.add(jpanel4);frame.add(jpanel5);frame.add(jpanel6);frame.add(jpanel7);frame.add(jpanel8);frame.add(jpanel9);frame.add(jpanel10);frame.add(jpanel11);frame.add(jpanel12);frame.add(jpanel13);frame.add(jpanel14);frame.add(jpanel15);frame.add(jpanel16);frame.add(jpanel17);frame.add(jpanel18);frame.add(jpanel19);frame.add(jpanel20);frame.add(jpanel1);
frame.setVisible(true);
frame.setSize(800,800);
}
}
